<!doctype html>
<html lang="en" class="light">

<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="<?= base_url('favicon-N.png') ?>?v=4">
    <link rel="shortcut icon" type="image/png" href="<?= base_url('favicon-N.png') ?>?v=4">
    <link rel="apple-touch-icon" href="<?= base_url('favicon-N.png') ?>?v=4">
    <title>Maintenance Report</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- DataTables core + Buttons -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#e3f5fe',
                            100: '#b9e6fc',
                            200: '#8bd5fb',
                            300: '#5cc4f9',
                            400: '#38b7f7',
                            500: '#04a9f5',
                            600: '#03a0ec',
                            700: '#0396e2',
                            800: '#028cd9',
                            900: '#017bc8'
                        },
                        sidebar: '#1c232f',
                        bodybg: '#f4f7fa'
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif']
                    },
                    spacing: {
                        'header': '74px',
                        'sidebar': '264px'
                    }
                }
            }
        }
    </script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: #f4f7fa;
        }

        .dark body {
            background: #1d2630;
        }

        ::-webkit-scrollbar {
            width: 8px;
            height: 8px
        }

        ::-webkit-scrollbar-thumb {
            background: #b9c1c9;
            border-radius: 4px
        }

        .dark ::-webkit-scrollbar-thumb {
            background: #3a4658
        }

        .card {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 1px 20px 0 rgba(69, 90, 100, .08);
            margin-bottom: 24px;
        }

        .dark .card {
            background: #263240;
            color: #bfc8d6;
            box-shadow: none
        }

        .card-body {
            padding: 25px
        }

        .pc-sidebar {
            transition: transform .25s ease, width .25s ease
        }

        .pc-link.active {
            color: #fff !important;
        }

        .pc-link.active .pc-micon {
            color: #04a9f5
        }

        .dropdown-menu {
            display: none;
        }

        .dropdown-menu.show {
            display: block;
        }

        /* ===== JUMLAH PER GROUP ===== */
        .grup-count {
            display: inline-block;
            min-width: 28px;
            padding: 2px 8px;
            border-radius: 6px;
            background: #f1f5f9;
            color: #94a3b8;
            font-weight: 600;
            text-align: center;
        }

        .grup-count.has {
            background: #e3edfb;
            color: #1e4fa3;
        }

        .grup-icon {
            width: 44px;
            height: 44px;
            border-radius: 10px;
            background: #e3edfb;
            color: #1e4fa3;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .rekap-red {
            background: #fde8ec;
        }

        .rekap-amber {
            background: #fdf3e3;
        }

        .rekap-blue {
            background: #e3edfb;
        }

        .rekap-green {
            background: #e7f8f1;
        }

        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: all .3s ease;
        }

        .submenu.open {
            max-height: 1000px;
            overflow: visible;
        }

        @media (max-width:1024px) {
            .pc-sidebar {
                transform: translateX(-100%);
                position: fixed;
                z-index: 1050;
            }

            .pc-sidebar.mobile-open {
                transform: translateX(0);
            }

            .pc-container {
                margin-left: 0 !important;
            }
        }

        .brand-text {
            font-size: 18px;
        }

    </style>
    <link rel="stylesheet" href="<?= base_url('assets/theme/rfo.css') ?>?v=<?= @filemtime(FCPATH . 'assets/theme/rfo.css') ?: '1' ?>">
    <script src="<?= base_url('assets/theme/rfo.js') ?>?v=<?= @filemtime(FCPATH . 'assets/theme/rfo.js') ?: '1' ?>" defer></script>
    <?= view('partials/theme') ?>
</head>

<body class="text-[#37474f] dark:text-[#bfc8d6]">
    <!-- ============ SIDEBAR ============ -->
    <nav id="sidebar" class="pc-sidebar fixed top-0 left-0 h-screen w-sidebar bg-sidebar text-[#a9b7c6] z-[1030] flex flex-col">
        <!-- brand -->
        <div class="flex items-center h-header px-6 shrink-0">
            <a href="#" class="flex items-center gap-2 text-white text-2xl font-semibold">
                <span class="text-primary-500"></span>
                <span class="brand-text">Sistem Operasional <br> JWI Group</span>
            </a>
        </div>
        <?php if (session()->getFlashdata('success')) : ?>
            <div id="successAlert" class="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4">
                <div class="bg-green-500 text-white rounded-xl shadow-xl overflow-hidden">
                    <div class="flex items-center gap-3 px-5 py-4">
                        <i class="ti ti-circle-check text-3xl"></i>
                        <div>
                            <h4 class="font-bold">Berhasil</h4>
                            <p class="text-sm"><?= session()->getFlashdata('success') ?></p>
                        </div>
                    </div>
                    <div class="h-1 bg-green-400">
                        <div id="progressBar" class="h-full bg-white w-full"></div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('error')) : ?>
            <div id="errorAlert" class="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4">
                <div class="bg-red-500 text-white rounded-xl shadow-xl overflow-hidden">
                    <div class="flex items-center gap-3 px-5 py-4">
                        <i class="ti ti-alert-circle text-3xl"></i>
                        <div>
                            <h4 class="font-bold">Gagal</h4>
                            <p class="text-sm"><?= session()->getFlashdata('error') ?></p>
                        </div>
                    </div>
                    <div class="h-1 bg-red-400">
                        <div id="progressBarError" class="h-full bg-white w-full"></div>
                    </div>
                </div>
            </div>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const box = document.getElementById('errorAlert');
                    const bar = document.getElementById('progressBarError');
                    if (!box) return;
                    if (bar) {
                        bar.style.transition = 'width 4s linear';
                        setTimeout(function() {
                            bar.style.width = '0%';
                        }, 100);
                    }
                    setTimeout(function() {
                        box.style.transition = 'all .5s ease';
                        box.style.opacity = '0';
                        box.style.transform = 'translate(-50%, -20px)';
                        setTimeout(function() {
                            box.remove();
                        }, 500);
                    }, 4000);
                });
            </script>
        <?php endif; ?>
        <!-- menu -->
        <div class="flex-1 overflow-y-auto overflow-x-hidden py-2.5">
            <ul class="px-0">
                <li class="px-6 py-3 text-[11px] uppercase tracking-wide text-[#5b6b7f] font-semibold">Halaman Utama</li>
                <li>
                    <a href="<?= site_url('dashboard-manager') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white relative">
                        <span class="pc-micon w-5"><i class="ti ti-home fs-5"></i></span>
                        <span class="pc-mtext">Beranda</span>
                    </a>
                </li>
                <li class="px-6 py-3 text-[11px] uppercase tracking-wide text-[#5b6b7f] font-semibold">Data Toko JWI Group</li>

                <li class="hasmenu">
                    <a href="#" onclick="toggleSub(this);return false;" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-building-store fs-1"></i></span>
                        <span class="flex-1">Data Toko</span>
                        <i data-feather="chevron-right" class="arrow w-4 h-4 transition-transform"></i>
                    </a>
                    <ul class="submenu bg-black/20">
                        <li><a href="<?= site_url('Alfamidi') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">ALFAMIDI</a></li>
                        <li><a href="<?= site_url('Lawson') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">LAWSON</a></li>
                        <li><a href="<?= site_url('Alfamart') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">ALFAMART</a></li>
                    </ul>
                </li>
                <li class="hasmenu">
                    <a href="#" onclick="toggleSub(this);return false;" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-brand-databricks"></i></span>
                        <span class="flex-1">Data Penggunaan</span>
                        <i data-feather="chevron-right" class="arrow w-4 h-4 transition-transform"></i>
                    </a>
                    <ul class="submenu bg-black/20">
                        <li><a href="<?= site_url('DataSI') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Simcard</a></li>
                        <li><a href="<?= site_url('NMRInet') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Nomor Inet</a></li>
                    </ul>
                </li>
                <li class="hasmenu">
                    <a href="#" onclick="toggleSub(this);return false;" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-category"></i></span>
                        <span class="flex-1">Master Data</span>
                        <i data-feather="chevron-right" class="arrow w-4 h-4 transition-transform"></i>
                    </a>
                    <ul class="submenu bg-black/20">
                        <li><a href="<?= site_url('Perangkat') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Merek Perangkat</a></li>
                        <li><a href="<?= site_url('Jns_perangkat') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Jenis Perangkat</a></li>
                        <li><a href="<?= site_url('TypePerangkat') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Type Perangkat</a></li>
                        <li><a href="<?= site_url('Vendor') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Vendor Non Celullar</a></li>
                        <li><a href="<?= site_url('VendorCelulllar') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Vendor Celulllar</a></li>
                        <li><a href="<?= site_url('LayananVendor') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Layanan Vendor</a></li>
                        <li><a href="<?= site_url('DCAdmin') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">DC</a></li>
                        <li><a href="<?= site_url('MediaKoneksi') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Media Koneksi</a></li>
                        <li><a href="<?= site_url('PemilikProject') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Pemilik Projek</a></li>
                        <li><a href="<?= site_url('Pelanggan') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Kategori Pelanggan</a></li>
                        <li><a href="<?= site_url('NomorInet') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Nomor INET</a></li>
                        <li><a href="<?= site_url('QuotaSIMCARD') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Kuota Simcard</a></li>
                        <li><a href="<?= site_url('VPN') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">VPN</a></li>
                    </ul>
                </li>
                <li><a href="<?= site_url('Map') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white"><span class="pc-micon w-5"><i class="ti ti-map-pin"></i></span><span>Lokasi</span></a></li>
                <li class="px-6 py-3 text-[11px] uppercase tracking-wide text-[#5b6b7f] font-semibold">Activation</li>
                <li>
                    <a href="<?= site_url('Spk') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-file-certificate"></i></span>
                        <span>SPK</span>
                    </a>
                </li>
                <li>
                    <a href="<?= site_url('SuratTugas') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-file-text"></i></span>
                        <span>Surat Tugas</span>
                    </a>
                </li>
                <li class="hasmenu">
                    <a href="#" onclick="toggleSub(this);return false;" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-file-check"></i></span>
                        <span class="flex-1">BAST</span>
                        <i data-feather="chevron-right" class="arrow w-4 h-4 transition-transform"></i>
                    </a>
                    <ul class="submenu bg-black/20">
                        <li><a href="<?= site_url('BastCorporate') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Corporate</a></li>
                        <li><a href="<?= site_url('BastAlfamidi') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Alfamidi</a></li>
                        <li><a href="<?= site_url('BastLawson') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Lawson</a></li>
                        <li><a href="<?= site_url('BastAlfamart') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Alfamart</a></li>
                        <li><a href="<?= site_url('BastDandan') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Dandan</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?= site_url('PksContract') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-file-text"></i></span>
                        <span>PKS &amp; Contract</span>
                    </a>
                </li>
                <li class="px-6 py-3 text-[11px] uppercase tracking-wide text-[#5b6b7f] font-semibold">NOC Operation</li>
                <li>
                    <a href="<?= site_url('RFO') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-file-alert"></i></span>
                        <span>RFO</span>
                    </a>
                </li>
                <li>
                    <a href="<?= site_url('MDMaintenance') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-tool"></i></span>
                        <span>Notifikasi Maintenance</span>
                    </a>
                </li>
                <li class="hasmenu">
                    <a href="#" onclick="toggleSub(this);return false;" class="pc-link active flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-history"></i></span>
                        <span class="flex-1">Report NOC</span>
                        <i data-feather="chevron-right" class="arrow w-4 h-4 transition-transform"></i>
                    </a>
                    <ul class="submenu bg-black/20">
                        <li><a href="<?= site_url('HistoryReport') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Daily Report</a></li>
                        <li><a href="<?= site_url('MaintenanceReport') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Maintenance Report</a></li>
                        <li><a href="<?= site_url('ReportSat') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Daily Report SAT Group</a></li>
                        <li><a href="<?= site_url('MonthlyReport') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Monthly Report</a></li>
                        <li><a href="<?= site_url('SurveyReport') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Survey Report</a></li>
                        <li><a href="<?= site_url('InstallationReport') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Installation Report</a></li>
                        <li><a href="<?= site_url('TroubleshootReport') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Troubleshoot Report</a></li>
                        <li><a href="<?= site_url('PreventiveMaintenance') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Preventive Maintenance</a></li>
                    </ul>
                </li>
                <li class="hasmenu">
                    <a href="#" onclick="toggleSub(this);return false;" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-category"></i></span>
                        <span class="flex-1">Data Teknis NOC</span>
                        <i data-feather="chevron-right" class="arrow w-4 h-4 transition-transform"></i>
                    </a>
                    <ul class="submenu bg-black/20">
                        <li><a href="<?= site_url('DataRakDC') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data Rak DC</a></li>
                        <li><a href="<?= site_url('Interkoneksi') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data Center &amp; Interkoneksi</a></li>
                        <li><a href="<?= site_url('Vlan') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data VLAN</a></li>
                        <li><a href="<?= site_url('NetMon') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">NetMon</a></li>
                        <li><a href="<?= site_url('DataRouter') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data Router</a></li>
                        <li><a href="<?= site_url('DataSwitch') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data Switch</a></li>
                        <li><a href="<?= site_url('DataOlt') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data OLT</a></li>
                        <li><a href="<?= site_url('DataCctv') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data CCTV</a></li>
                        <li><a href="<?= site_url('IpPublic') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data IP Addres</a></li>
                        <li><a href="<?= site_url('RekapDataMidi') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] text-white font-semibold">Rekap Data Toko</a></li>
                        <li><a href="<?= site_url('FtpClient') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">FTP Client</a></li>
                        <li><a href="<?= site_url('DataOdcOdp') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data ODC &amp; ODP</a></li>
                        <li><a href="<?= site_url('Kmz') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">KMZ</a></li>
                        <li><a href="<?= site_url('DevicesBackbone') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Devices Backbone</a></li>
                        <li><a href="<?= site_url('Bts') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data BTS</a></li>
                        <li><a href="<?= site_url('PelangganNoc') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data Pelanggan</a></li>
                        <li><a href="<?= site_url('VendorNoc') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data Vendor</a></li>
                        <li><a href="<?= site_url('InventoryKantor') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Asset Management</a></li>
                        <li><a href="<?= site_url('DataTopologi') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Data Topologi</a></li>
                    </ul>
                </li>
                <li class="hasmenu">
                    <a href="#" onclick="toggleSub(this);return false;" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-calendar-week"></i></span>
                        <span class="flex-1">Jadwal NOC</span>
                        <i data-feather="chevron-right" class="arrow w-4 h-4 transition-transform"></i>
                    </a>
                    <ul class="submenu bg-black/20">
                        <li><a href="<?= site_url('Calendar') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Shift</a></li>
                        <li><a href="<?= site_url('Piket') ?>" class="block pl-[52px] pr-6 py-2 text-[13px] hover:text-white">Piket</a></li>
                    </ul>
                </li>

                <li class="px-6 py-3 text-[11px] uppercase tracking-wide text-[#5b6b7f] font-semibold">Informasi</li>
                <li>
                    <a href="<?= site_url('Profile') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-user-circle"></i></span>
                        <span>Profile</span>
                    </a>
                </li>
                <li>
                    <a href="<?= site_url('settings') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-settings"></i></span>
                        <span>Pengguna</span>
                    </a>
                </li>
                <li>
                    <a href="<?= site_url('Logs') ?>" class="pc-link flex items-center gap-3 px-6 py-2.5 text-[14px] hover:text-white">
                        <span class="pc-micon w-5"><i class="ti ti-report-search"></i></span>
                        <span>Change Log</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- ============ MAIN ============ -->
    <div id="container" class="pc-container ml-sidebar min-h-screen transition-[margin] duration-200">

        <!-- HEADER -->
        <header class="pc-header sticky top-0 z-[1025] bg-white dark:bg-[#263240] h-header flex items-center px-6 shadow-[0_1px_20px_0_rgba(69,90,100,.08)]">
            <ul class="flex items-center gap-1">
                <li><a href="#" onclick="toggleSidebar();return false;" class="head-link flex items-center justify-center w-10 h-10 rounded hover:bg-gray-100 dark:hover:bg-white/5"><i data-feather="menu"></i></a></li>
            </ul>

            <ul class="flex items-center gap-1 ml-auto">
                <li class="relative dropdown">
                    <a href="#" onclick="toggleDrop(event,this)" class="head-link flex items-center justify-center w-10 h-10 rounded hover:bg-gray-100 dark:hover:bg-white/5"><i data-feather="user"></i></a>
                    <div class="dropdown-menu absolute right-0 mt-1 w-64 bg-white dark:bg-[#263240] rounded shadow-lg overflow-hidden border border-gray-100 dark:border-white/10">
                        <div class="flex items-center gap-3 px-5 py-4 bg-primary-500 text-white">
                            <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                                <i data-feather="user" class="w-5 h-5 text-gray-500"></i>
                            </div>
                            <div>
                                <h6 class="font-medium leading-tight"><?= session('username') ?></h6>
                            </div>
                        </div>
                        <div class="py-3 px-3">
                            <button onclick="window.location.href='<?= site_url('logout') ?>'" class="w-full mt-3 bg-primary-500 hover:bg-red-600 text-white py-2 rounded flex items-center justify-center gap-2 text-sm">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </button>
                        </div>
                    </div>
                </li>
            </ul>
        </header>

        <div class="rfo-page p-6">
            <!-- JUDUL -->
            <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
                <div class="flex items-center gap-4">
                    <span class="rfo-title-ic is-amber"><i class="ti ti-tool"></i></span>
                    <h1 class="rfo-title">Maintenance Report</h1>
                </div>
                <button type="button" onclick="openReportModal()" class="rfo-btn rfo-btn-blue">
                    <i class="ti ti-plus"></i> Tambah
                </button>
            </div>

            <div class="card">
                <div class="card-body">

                    <!-- TOOLBAR -->
                    <?php
                    // Opsi filter: nilai unik (satu pelanggan / tiket bisa muncul di beberapa report)
                    $opsiUnik = static function (array $rows, string $kolom): array {
                        $nilai = array_unique(array_filter(array_map('trim', array_column($rows, $kolom)), 'strlen'));
                        natcasesort($nilai);
                        return $nilai;
                    };
                    ?>
                    <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
                        <div class="flex items-center gap-3 flex-wrap">
                            <div id="lengthArea"></div>
                            <?php
                            // Filter Bulan: daftar bulan (YYYY-MM) dari tanggal report, terbaru di atas
                            $namaBulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                            $opsiBulan = [];
                            foreach ($report ?? [] as $row) {
                                $tgl = (string) (($row['tanggal_report'] ?? '') ?: ($row['created_at'] ?? ''));
                                if ($tgl !== '') {
                                    $opsiBulan[substr($tgl, 0, 7)] = $namaBulan[(int) substr($tgl, 5, 2)] . ' ' . substr($tgl, 0, 4);
                                }
                            }
                            krsort($opsiBulan);
                            ?>
                            <select id="filterBulan" class="filter-select" title="Filter Bulan">
                                <option value="">Semua Bulan</option>
                                <?php foreach ($opsiBulan as $ym => $label) : ?>
                                    <option value="<?= esc($ym) ?>"><?= esc($label) ?></option>
                                <?php endforeach; ?>
                            </select>

                            <!-- FILTER -->
                            <select id="filterStatus" class="filter-select" title="Filter Status">
                                <option value="">Semua Status</option>
                                <?php foreach (array_keys($statusList) as $st) : ?>
                                    <option value="<?= esc($st) ?>"><?= esc($st) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select id="filterJenis" class="filter-select" title="Filter Jenis">
                                <option value="">Semua Jenis</option>
                                <?php foreach (['Maintenance', 'Perpindahan Perangkat', 'Gangguan'] as $jn) : ?>
                                    <option value="<?= esc($jn) ?>"><?= esc($jn) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select id="filterIdPelanggan" class="filter-select" title="Filter ID Pelanggan">
                                <option value="">Semua ID Pelanggan</option>
                                <?php foreach ($opsiUnik($report, 'id_pelanggan') as $idp) : ?>
                                    <option value="<?= esc($idp) ?>"><?= esc($idp) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select id="filterNoTiket" class="filter-select" title="Filter No Tiket">
                                <option value="">Semua No Tiket</option>
                                <?php foreach ($opsiUnik($report, 'no_tiket') as $tiket) : ?>
                                    <option value="<?= esc($tiket) ?>"><?= esc($tiket) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="flex items-center gap-3 flex-wrap">
                            <div class="rfo-search">
                                <i class="ti ti-search"></i>
                                <input type="text" id="customSearch" placeholder="Cari data..." />
                            </div>
                            <button type="button" class="rfo-ghost-btn rfo-reset"><i class="ti ti-refresh"></i> Reset</button>
                            <div id="exportArea"></div>
                        </div>
                    </div>

                    <!-- TABLE -->
                    <div class="table-scroll">
                        <table id="reportTable" class="rfo-table display nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Aksi</th>
                                    <th>Nama</th>
                                    <th>ID Pelanggan</th>
                                    <th>Nama Pelanggan</th>
                                    <th>Alamat</th>
                                    <th>ODP (Port)</th>
                                    <th>Jenis</th>
                                    <th>Tanggal &amp; Jam Kendala</th>
                                    <th>Kendala</th>
                                    <th>No Tiket</th>
                                    <th>Action</th>
                                    <th>Tanggal Report</th>
                                    <th>Status</th>
                                    <th>Tanggal &amp; Jam Resolved</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($report)) : ?>
                                    <?php $no = 1; ?>
                                    <?php $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']; ?>
                                    <?php foreach ($report as $row) : ?>
                                        <?php
                                        $jenis = [];
                                        if (!empty($row['maintenance'])) $jenis[] = 'Maintenance';
                                        if (!empty($row['perpindahan_perangkat'])) $jenis[] = 'Perpindahan Perangkat';
                                        if (!empty($row['gangguan'])) $jenis[] = 'Gangguan';
                                        // Tanggal & jam kendala. Format: 1 Oktober 2026 14:30
                                        $tsKendala = !empty($row['waktu_kendala']) ? strtotime($row['waktu_kendala']) : false;
                                        $waktuKendala = $tsKendala ? date('j', $tsKendala) . ' ' . $bulan[(int) date('n', $tsKendala)] . ' ' . date('Y H:i', $tsKendala) : '-';
                                        // Tanggal & jam resolved (otomatis saat status Resolved). Format: 1 Oktober 2026 14:30:05
                                        $tsResolved = !empty($row['waktu_resolved']) ? strtotime($row['waktu_resolved']) : false;
                                        $waktuResolved = $tsResolved ? date('j', $tsResolved) . ' ' . $bulan[(int) date('n', $tsResolved)] . ' ' . date('Y H:i:s', $tsResolved) : '-';
                                        // Tanggal report diisi manual; data lama pakai created_at. Format: 1 Oktober 2026
                                        $tglRaw = ($row['tanggal_report'] ?? '') ?: ($row['created_at'] ?? '');
                                        $ts = $tglRaw ? strtotime($tglRaw) : false;
                                        $tglReport = $ts ? date('j', $ts) . ' ' . $bulan[(int) date('n', $ts)] . ' ' . date('Y', $ts) : '-';
                                        ?>
                                        <tr data-bulan="<?= esc(substr((string) (($row['tanggal_report'] ?? '') ?: ($row['created_at'] ?? '')), 0, 7), 'attr') ?>">
                                            <td><?= $no++; ?></td>
                                            <td>
                                                <button type="button"
                                                    data-row="<?= esc(json_encode($row), 'attr') ?>"
                                                    onclick="openReportModal(JSON.parse(this.dataset.row))"
                                                    class="btn btn-sm btn-primary" title="Edit">
                                                    <i class="ti ti-edit"></i> <span>Edit</span>
                                                </button>

                                                <button type="button"
                                                    onclick="confirmDelete(<?= $row['id'] ?>)"
                                                    class="btn btn-sm btn-danger" title="Hapus">
                                                    <i class="ti ti-trash"></i> <span>Hapus</span>
                                                </button>

                                                <button type="button"
                                                    data-row="<?= esc(json_encode($row), 'attr') ?>"
                                                    onclick="openViewModal(JSON.parse(this.dataset.row))"
                                                    class="btn btn-sm btn-info" title="View">
                                                    <i class="ti ti-eye"></i> <span>View</span>
                                                </button>
                                            </td>
                                            <td class="whitespace-normal min-w-[140px]"><?= esc($row['nama']); ?></td>
                                            <td data-search="<?= esc(trim($row['id_pelanggan']), 'attr') ?>"><?= esc($row['id_pelanggan']); ?></td>
                                            <td class="whitespace-normal min-w-[160px]"><?= esc($row['nama_pelanggan']); ?></td>
                                            <td class="whitespace-pre-line min-w-[220px]"><?= esc($row['alamat']); ?></td>
                                            <td class="whitespace-normal min-w-[120px]"><?= esc($row['odp_port']); ?></td>
                                            <td class="whitespace-normal min-w-[150px]" data-search="<?= esc('|' . implode('|', $jenis) . '|', 'attr') ?>"><?= $jenis ? esc(implode(', ', $jenis)) : '-' ?></td>
                                            <td class="min-w-[150px]" data-order="<?= esc($row['waktu_kendala'] ?? '', 'attr') ?>"><?= esc($waktuKendala); ?></td>
                                            <td class="whitespace-pre-line min-w-[240px]"><?= esc($row['kendala']); ?></td>
                                            <td data-search="<?= esc(trim($row['no_tiket']), 'attr') ?>"><?= esc($row['no_tiket']); ?></td>
                                            <td class="whitespace-pre-line min-w-[240px]"><?= esc($row['action']); ?></td>
                                            <td data-order="<?= esc($tglRaw, 'attr') ?>"><?= esc($tglReport); ?></td>
                                            <td data-search="<?= esc($row['status'], 'attr') ?>"><span class="badge <?= $statusList[$row['status']] ?? 'badge-draft' ?>"><?= esc($row['status']); ?></span></td>
                                            <td class="min-w-[160px]" data-order="<?= esc($row['waktu_resolved'] ?? '', 'attr') ?>"><?= esc($waktuResolved); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- ====== POP UP TAMBAH / EDIT ====== -->
    <div id="reportModal" class="fixed inset-0 bg-black/50 hidden z-[1100] flex items-center justify-center p-4">
        <div class="bg-white dark:bg-[#263240] rounded-xl shadow-xl w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-5">
                <h3 class="text-xl font-bold" id="reportModalTitle">Tambah Maintenance Report</h3>
                <button type="button" onclick="closeReportModal()"><i class="ti ti-x text-2xl"></i></button>
            </div>

            <form action="<?= site_url('MaintenanceReport/save') ?>" method="POST" id="reportForm">
                <?= csrf_field() ?>
                <input type="hidden" name="id" id="r_id">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Tanggal Report <span class="text-red-500">*</span></label>
                        <input type="date" name="tanggal_report" id="r_tanggal_report" required class="w-full border rounded-lg p-3">
                    </div>
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Nama <span class="text-red-500">*</span></label>
                        <!-- nama diambil dari data shift (jadwal_noc), seperti Daily Report -->
                        <select name="nama" id="r_nama" required class="w-full border rounded-lg p-3">
                            <option value="">-- Pilih Nama --</option>
                            <?php foreach ($namaOptions as $nama) : ?>
                                <option value="<?= esc($nama, 'attr') ?>"><?= esc($nama) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($namaOptions)) : ?>
                            <p class="text-[12px] text-gray-500 mt-1">Belum ada nama di data Shift (Jadwal NOC).</p>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label class="text-sm font-medium">ID Pelanggan <span class="text-red-500">*</span></label>
                        <input type="text" name="id_pelanggan" id="r_id_pelanggan" maxlength="100" required placeholder="Masukkan ID pelanggan" class="w-full border rounded-lg p-3">
                    </div>
                    <div>
                        <label class="text-sm font-medium">Nama Pelanggan <span class="text-red-500">*</span></label>
                        <input type="text" name="nama_pelanggan" id="r_nama_pelanggan" maxlength="255" required placeholder="Masukkan nama pelanggan" class="w-full border rounded-lg p-3">
                    </div>
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Alamat <span class="text-red-500">*</span></label>
                        <textarea name="alamat" id="r_alamat" rows="2" required placeholder="Masukkan alamat" class="w-full border rounded-lg p-3"></textarea>
                    </div>
                    <div>
                        <label class="text-sm font-medium">ODP (Port) <span class="text-red-500">*</span></label>
                        <input type="text" name="odp_port" id="r_odp_port" maxlength="255" required placeholder="Contoh: ODP-01 / Port 3" class="w-full border rounded-lg p-3">
                    </div>
                    <div>
                        <label class="text-sm font-medium">No Tiket <span class="text-red-500">*</span></label>
                        <input type="text" name="no_tiket" id="r_no_tiket" maxlength="100" required placeholder="Masukkan nomor tiket" class="w-full border rounded-lg p-3">
                    </div>
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Jenis</label>
                        <div class="flex flex-wrap gap-x-6 gap-y-2 mt-2">
                            <label class="flex items-center gap-2 text-sm cursor-pointer">
                                <input type="checkbox" name="maintenance" id="r_maintenance" value="1" class="w-4 h-4"> Maintenance
                            </label>
                            <label class="flex items-center gap-2 text-sm cursor-pointer">
                                <input type="checkbox" name="perpindahan_perangkat" id="r_perpindahan_perangkat" value="1" class="w-4 h-4"> Perpindahan Perangkat
                            </label>
                            <label class="flex items-center gap-2 text-sm cursor-pointer">
                                <input type="checkbox" name="gangguan" id="r_gangguan" value="1" class="w-4 h-4"> Gangguan
                            </label>
                        </div>
                    </div>
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Tanggal &amp; Jam Kendala <span class="text-red-500">*</span></label>
                        <input type="datetime-local" name="waktu_kendala" id="r_waktu_kendala" required class="w-full border rounded-lg p-3">
                    </div>
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Kendala <span class="text-red-500">*</span></label>
                        <textarea name="kendala" id="r_kendala" rows="3" required placeholder="Masukkan kendala" class="w-full border rounded-lg p-3"></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Action <span class="text-red-500">*</span></label>
                        <textarea name="action" id="r_action" rows="3" required placeholder="Masukkan action yang dilakukan" class="w-full border rounded-lg p-3"></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="text-sm font-medium">Status <span class="text-red-500">*</span></label>
                        <select name="status" id="r_status" required class="w-full border rounded-lg p-3">
                            <?php foreach (array_keys($statusList) as $st) : ?>
                                <option value="<?= esc($st, 'attr') ?>"><?= esc($st) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <!-- Muncul & terisi otomatis (jam komputer) saat status diubah ke Resolved -->
                    <div class="md:col-span-2 hidden" id="r_waktu_resolved_wrap">
                        <label class="text-sm font-medium">Tanggal &amp; Jam Resolved</label>
                        <input type="datetime-local" step="1" name="waktu_resolved" id="r_waktu_resolved" readonly class="w-full border rounded-lg p-3 bg-[#f1f5f9] dark:bg-white/10 dark:text-white dark:[color-scheme:dark]">
                    </div>
                </div>
                <div class="flex justify-end gap-3 mt-6">
                    <button type="button" onclick="closeReportModal()" class="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg">Batal</button>
                    <button type="submit" id="reportSubmit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg">Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ====== POP UP VIEW ====== -->
    <div id="viewModal" class="fixed inset-0 bg-black/50 hidden z-[1100] flex items-center justify-center p-4" onclick="if (event.target === this) closeViewModal()">
        <div class="bg-white dark:bg-[#263240] rounded-xl shadow-xl w-full max-w-2xl p-6 max-h-[90vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-5">
                <h3 class="text-xl font-bold">View Maintenance Report</h3>
                <button type="button" onclick="closeViewModal()"><i class="ti ti-x text-2xl"></i></button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                    <div class="text-gray-500">Nama</div>
                    <div class="font-medium" id="v_nama"></div>
                </div>
                <div>
                    <div class="text-gray-500">Status</div>
                    <div><span id="v_status" class="badge"></span></div>
                </div>
                <div>
                    <div class="text-gray-500">Tanggal &amp; Jam Resolved</div>
                    <div class="font-medium" id="v_waktu_resolved"></div>
                </div>
                <div>
                    <div class="text-gray-500">ID Pelanggan</div>
                    <div class="font-medium" id="v_id_pelanggan"></div>
                </div>
                <div>
                    <div class="text-gray-500">Nama Pelanggan</div>
                    <div class="font-medium" id="v_nama_pelanggan"></div>
                </div>
                <div class="md:col-span-2">
                    <div class="text-gray-500">Alamat</div>
                    <div class="font-medium whitespace-pre-line" id="v_alamat"></div>
                </div>
                <div>
                    <div class="text-gray-500">ODP (Port)</div>
                    <div class="font-medium" id="v_odp_port"></div>
                </div>
                <div>
                    <div class="text-gray-500">No Tiket</div>
                    <div class="font-medium" id="v_no_tiket"></div>
                </div>
                <div>
                    <div class="text-gray-500">Jenis</div>
                    <div class="font-medium" id="v_jenis"></div>
                </div>
                <div>
                    <div class="text-gray-500">Tanggal Report</div>
                    <div class="font-medium" id="v_tanggal_report"></div>
                </div>
                <div>
                    <div class="text-gray-500">Dibuat</div>
                    <div class="font-medium" id="v_created"></div>
                </div>
                <div>
                    <div class="text-gray-500">Tanggal &amp; Jam Kendala</div>
                    <div class="font-medium" id="v_waktu_kendala"></div>
                </div>
                <div class="md:col-span-2">
                    <div class="text-gray-500">Kendala</div>
                    <div class="font-medium whitespace-pre-line" id="v_kendala"></div>
                </div>
                <div class="md:col-span-2">
                    <div class="text-gray-500">Action</div>
                    <div class="font-medium whitespace-pre-line" id="v_action"></div>
                </div>
            </div>
            <div class="flex justify-end gap-3 mt-6">
                <button type="button" onclick="closeViewModal()" class="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-lg">Tutup</button>
            </div>
        </div>
    </div>

    <script>
        // ====== VIEW ======
        const BULAN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        // '2026-10-01' -> '1 Oktober 2026'
        const tglIndo = t => {
            if (!t) return '-';
            const [y, m, d] = t.split('-');
            return Number(d) + ' ' + BULAN[Number(m) - 1] + ' ' + y;
        };
        const STATUS_BADGE = <?= json_encode($statusList) ?>;

        function openViewModal(d) {
            const set = (id, v) => document.getElementById(id).textContent = v || '-';
            set('v_nama', d.nama);
            set('v_id_pelanggan', d.id_pelanggan);
            set('v_nama_pelanggan', d.nama_pelanggan);
            set('v_alamat', d.alamat);
            set('v_odp_port', d.odp_port);
            set('v_no_tiket', d.no_tiket);
            set('v_kendala', d.kendala);
            set('v_action', d.action);

            const jenis = [];
            if (Number(d.maintenance)) jenis.push('Maintenance');
            if (Number(d.perpindahan_perangkat)) jenis.push('Perpindahan Perangkat');
            if (Number(d.gangguan)) jenis.push('Gangguan');
            set('v_jenis', jenis.join(', '));
            set('v_tanggal_report', tglIndo((d.tanggal_report || d.created_at || '').substring(0, 10)));
            set('v_waktu_kendala', d.waktu_kendala ? tglIndo(d.waktu_kendala.substring(0, 10)) + ' ' + d.waktu_kendala.substring(11, 16) : '');
            set('v_waktu_resolved', d.waktu_resolved ? tglIndo(d.waktu_resolved.substring(0, 10)) + ' ' + d.waktu_resolved.substring(11, 19) : '');
            set('v_created', d.created_at ? tglIndo(d.created_at.substring(0, 10)) + ' ' + d.created_at.substring(11, 16) : '');

            const st = document.getElementById('v_status');
            st.textContent = d.status || '-';
            st.className = 'badge ' + (STATUS_BADGE[d.status] || 'badge-draft');

            document.getElementById('viewModal').classList.remove('hidden');
        }

        function closeViewModal() {
            document.getElementById('viewModal').classList.add('hidden');
        }
    </script>

    <script>
        // ====== POP UP TAMBAH / EDIT ======
        const URL_SAVE = "<?= site_url('MaintenanceReport/save') ?>";
        const URL_UPDATE = "<?= site_url('MaintenanceReport/update') ?>";

        // Pilih nama; nama yang tidak ada lagi di data shift tetap ditampilkan (seperti Daily Report)
        function setNama(nama) {
            const sel = document.getElementById('r_nama');
            sel.querySelectorAll('option[data-extra]').forEach(o => o.remove());
            if (nama && ![...sel.options].some(o => o.value === nama)) {
                const opt = new Option(nama, nama);
                opt.dataset.extra = '1';
                sel.add(opt);
            }
            sel.value = nama || '';
        }

        // d kosong = tambah; d berisi data baris = edit
        function openReportModal(d) {
            d = d || {};
            const isEdit = !!d.id;
            const f = document.getElementById('reportForm');
            f.reset();
            f.action = isEdit ? URL_UPDATE : URL_SAVE;
            document.getElementById('reportModalTitle').textContent = isEdit ? 'Edit Maintenance Report' : 'Tambah Maintenance Report';
            document.getElementById('reportSubmit').textContent = isEdit ? 'Update' : 'Simpan';

            document.getElementById('r_id').value = d.id || '';
            const hariIni = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().substring(0, 10);
            document.getElementById('r_tanggal_report').value = d.tanggal_report || (d.created_at || '').substring(0, 10) || hariIni;
            setNama(d.nama || '');
            document.getElementById('r_id_pelanggan').value = d.id_pelanggan || '';
            document.getElementById('r_nama_pelanggan').value = d.nama_pelanggan || '';
            document.getElementById('r_alamat').value = d.alamat || '';
            document.getElementById('r_odp_port').value = d.odp_port || '';
            document.getElementById('r_no_tiket').value = d.no_tiket || '';
            document.getElementById('r_maintenance').checked = !!Number(d.maintenance);
            document.getElementById('r_perpindahan_perangkat').checked = !!Number(d.perpindahan_perangkat);
            document.getElementById('r_gangguan').checked = !!Number(d.gangguan);
            document.getElementById('r_waktu_kendala').value = (d.waktu_kendala || '').replace(' ', 'T').substring(0, 16);
            document.getElementById('r_kendala').value = d.kendala || '';
            document.getElementById('r_action').value = d.action || '';
            document.getElementById('r_status').value = d.status || 'On Progress';
            // Data lama tetap memakai waktu resolved yang tersimpan (2026-10-15 14:30:05 -> 2026-10-15T14:30:05)
            document.getElementById('r_waktu_resolved').value = (d.waktu_resolved || '').replace(' ', 'T').substring(0, 19);
            syncWaktuResolved();

            document.getElementById('reportModal').classList.remove('hidden');
        }

        // Status Resolved: tampilkan Tanggal & Jam Resolved, isi otomatis dengan jam komputer (Windows) bila belum ada.
        // Status lain: sembunyikan & kosongkan.
        function syncWaktuResolved() {
            const resolved = document.getElementById('r_status').value === 'Resolved';
            const input = document.getElementById('r_waktu_resolved');
            if (resolved && !input.value) {
                const now = new Date();
                input.value = new Date(now - now.getTimezoneOffset() * 60000).toISOString().substring(0, 19);
            }
            if (!resolved) input.value = '';
            document.getElementById('r_waktu_resolved_wrap').classList.toggle('hidden', !resolved);
        }
        document.getElementById('r_status').addEventListener('change', syncWaktuResolved);

        function closeReportModal() {
            document.getElementById('reportModal').classList.add('hidden');
        }

        // ====== VALIDASI SEBELUM SUBMIT ======
        document.getElementById('reportForm').addEventListener('submit', function(e) {
            const wajib = ['r_tanggal_report', 'r_nama', 'r_id_pelanggan', 'r_nama_pelanggan', 'r_alamat', 'r_odp_port', 'r_waktu_kendala', 'r_no_tiket', 'r_kendala', 'r_action', 'r_status']
                .map(id => document.getElementById(id).value.trim());

            if (wajib.includes('')) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Form Belum Lengkap',
                    text: 'Semua field bertanda * wajib diisi.',
                    confirmButtonColor: '#185a82'
                });
                return false;
            }
        });

        <?php
        // Gagal validasi di server: buka lagi pop up dengan isian terakhir
        $oldKeys = ['id', 'tanggal_report', 'nama', 'id_pelanggan', 'nama_pelanggan', 'alamat', 'odp_port', 'waktu_kendala', 'maintenance', 'perpindahan_perangkat', 'gangguan', 'kendala', 'no_tiket', 'action', 'status', 'waktu_resolved'];
        $oldData = [];
        foreach ($oldKeys as $k) {
            $oldData[$k] = old($k, null, false);
        }
        ?>
        <?php if ($oldData['nama'] !== null || $oldData['id_pelanggan'] !== null) : ?>
            openReportModal(<?= json_encode($oldData, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>);
        <?php endif; ?>
    </script>

    <script>
        // ====== DELETE ======
        function confirmDelete(id) {
            Swal.fire({
                title: 'Hapus Data?',
                text: 'Data yang dihapus tidak dapat dikembalikan.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc2626',
                cancelButtonColor: '#6b7280',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?= site_url('MaintenanceReport/delete/') ?>" + id;
                }
            });
        }

        function isTableEmpty(table) {
            return table.rows({
                search: 'applied'
            }).data().length === 0;
        }

        function showEmptyExportAlert() {
            Swal.fire({
                icon: 'warning',
                title: 'Data Kosong',
                text: 'Tidak ada data yang bisa diexport.',
                confirmButtonColor: '#04a9f5'
            });
        }
    </script>

    <script>
        // ---- Sidebar ----
        let collapsed = false;

        function toggleSidebar() {
            const sb = document.getElementById('sidebar'),
                c = document.getElementById('container');
            if (window.innerWidth < 1024) {
                sb.classList.toggle('mobile-open');
            } else {
                collapsed = !collapsed;
                if (collapsed) {
                    sb.style.transform = 'translateX(-100%)';
                    c.classList.remove('ml-sidebar');
                    c.style.marginLeft = '0';
                } else {
                    sb.style.transform = 'translateX(0)';
                    c.style.marginLeft = '';
                    c.classList.add('ml-sidebar');
                }
            }
        }

        function toggleDrop(e, el) {
            e.preventDefault();
            e.stopPropagation();
            const menu = el.parentElement.querySelector('.dropdown-menu');
            const isOpen = menu.classList.contains('show');
            document.querySelectorAll('.dropdown-menu.show').forEach(m => m.classList.remove('show'));
            if (!isOpen) menu.classList.add('show');
        }

        document.addEventListener('click', function(e) {
            if (window.innerWidth < 1024) {
                const sb = document.getElementById('sidebar');
                const menuBtn = e.target.closest('[onclick*="toggleSidebar"]');
                if (sb.classList.contains('mobile-open') && !sb.contains(e.target) && !menuBtn) {
                    sb.classList.remove('mobile-open');
                }
            }
            document.querySelectorAll('.dropdown-menu.show').forEach(m => m.classList.remove('show'));
        });

        function toggleSub(el) {
            const parent = el.closest('.hasmenu');
            const sub = parent.querySelector('.submenu');
            const arrow = parent.querySelector('.arrow');
            sub.classList.toggle('open');
            if (arrow) arrow.style.transform = sub.classList.contains('open') ? 'rotate(90deg)' : 'rotate(0deg)';
        }

        feather.replace();
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const alertBox = document.getElementById('successAlert');
            const progressBar = document.getElementById('progressBar');
            if (alertBox) {
                if (progressBar) {
                    progressBar.style.transition = "width 3s linear";
                    setTimeout(() => {
                        progressBar.style.width = "0%";
                    }, 100);
                }
                setTimeout(() => {
                    alertBox.style.transition = "all .5s ease";
                    alertBox.style.opacity = "0";
                    alertBox.style.transform = "translate(-50%, -20px)";
                    setTimeout(() => {
                        alertBox.remove();
                    }, 500);
                }, 3000);
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            const exportConfig = {
                exportOptions: {
                    columns: ':visible',
                    format: {
                        body: function(data) {
                            const tmp = document.createElement('div');
                            tmp.innerHTML = data;
                            return tmp.textContent.trim();
                        }
                    }
                }
            };

            const table = $('#reportTable').DataTable({
                pageLength: 10,
                lengthMenu: [
                    [10, 15, 25, 50, -1],
                    [10, 15, 25, 50, "Semua"]
                ],
                order: [],
                columnDefs: [{
                    targets: [0, 1],
                    orderable: false,
                    searchable: false
                }],
                dom: "lBfrtip",
                buttons: [{
                    extend: 'collection',
                    text: '<i class="ti ti-download"></i> Export',
                    className: 'export-toggle',
                    buttons: [{
                            extend: 'copyHtml5',
                            text: '<i class="ti ti-copy"></i> Copy',
                            title: 'Data Maintenance Report',
                            ...exportConfig,
                            action: function(e, dt, button, config) {
                                if (isTableEmpty(dt)) return showEmptyExportAlert();
                                $.fn.dataTable.ext.buttons.copyHtml5.action.call(this, e, dt, button, config);
                            }
                        },
                        {
                            extend: 'csvHtml5',
                            text: '<i class="ti ti-file-text"></i> Export CSV',
                            title: 'Data Maintenance Report',
                            ...exportConfig,
                            action: function(e, dt, button, config) {
                                if (isTableEmpty(dt)) return showEmptyExportAlert();
                                $.fn.dataTable.ext.buttons.csvHtml5.action.call(this, e, dt, button, config);
                            }
                        },
                        {
                            extend: 'excelHtml5',
                            text: '<i class="ti ti-file-spreadsheet"></i> Export Excel',
                            title: 'Data Maintenance Report',
                            ...exportConfig,
                            action: function(e, dt, button, config) {
                                if (isTableEmpty(dt)) return showEmptyExportAlert();
                                $.fn.dataTable.ext.buttons.excelHtml5.action.call(this, e, dt, button, config);
                            }
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="ti ti-file-type-pdf"></i> Export PDF',
                            title: 'Data Maintenance Report',
                            orientation: 'landscape',
                            pageSize: 'A4',
                            ...exportConfig,
                            action: function(e, dt, button, config) {
                                if (isTableEmpty(dt)) return showEmptyExportAlert();
                                $.fn.dataTable.ext.buttons.pdfHtml5.action.call(this, e, dt, button, config);
                            },
                            customize: function(doc) {
                                doc.styles.tableHeader = {
                                    fillColor: '#04a9f5',
                                    color: '#fff',
                                    bold: true,
                                    alignment: 'left'
                                };
                                doc.defaultStyle.fontSize = 10;
                                doc.content[1].layout = {
                                    hLineWidth: () => 0.5,
                                    vLineWidth: () => 0.5,
                                    hLineColor: () => '#e0e0e0',
                                    vLineColor: () => '#e0e0e0'
                                };
                            }
                        }
                    ]
                }],
                language: {
                    lengthMenu: "_MENU_",
                    info: "Menampilkan _START_ - _END_ dari _TOTAL_ data",
                    infoEmpty: "Menampilkan 0 - 0 dari 0 data",
                    infoFiltered: "(disaring dari _MAX_ data)",
                    emptyTable: "Data maintenance report belum tersedia",
                    zeroRecords: "Tidak ada data yang cocok dengan pencarian",
                    paginate: {
                        previous: "Sebelumnya",
                        next: "Selanjutnya"
                    }
                }
            });

            table.on('draw.dt order.dt search.dt', function() {
                let i = table.page.info().start;
                table.column(0, {
                    page: 'current',
                    search: 'applied',
                    order: 'applied'
                }).nodes().each(function(cell) {
                    cell.innerHTML = ++i;
                });
            });
            table.draw();

            $('#lengthArea').append($('.dataTables_length'));
            $('#exportArea').append($('.dt-buttons'));

            // ====== FILTER DROPDOWN (cocok persis pada kolom) ======
            function filterColumn(col, value) {
                const re = value ? '^' + $.fn.dataTable.util.escapeRegex(value) + '$' : '';
                table.column(col).search(re, true, false).draw();
            }
            $('#filterStatus').on('change', function() {
                filterColumn(13, this.value);
            });
            // Jenis bisa lebih dari satu per baris: cocokkan salah satu jenis (data-search |Jenis1|Jenis2|)
            $('#filterJenis').on('change', function() {
                const re = this.value ? '\\|' + $.fn.dataTable.util.escapeRegex(this.value) + '\\|' : '';
                table.column(7).search(re, true, false).draw();
            });
            $('#filterIdPelanggan').on('change', function() {
                filterColumn(3, this.value);
            });
            $('#filterNoTiket').on('change', function() {
                filterColumn(10, this.value);
            });

            // Filter Bulan: cocokkan data-bulan (YYYY-MM) di <tr>
            $.fn.dataTable.ext.search.push(function(settings, data, dataIndex) {
                const bulan = $('#filterBulan').val();
                return settings.nTable.id !== 'reportTable' || !bulan || settings.aoData[dataIndex].nTr.dataset.bulan === bulan;
            });
            $('#filterBulan').on('change', function() {
                table.draw();
            });

            $('#customSearch').on('keyup', function() {
                table.search(this.value).draw();
            });
            $('#customSearch').on('keypress', function(e) {
                if (e.which === 13) table.search(this.value).draw();
            });
        });
    </script>

    <?php if (!session()->get('logged_in')) : ?>
        <script>
            window.location.href = "<?= base_url('/login') ?>";
        </script>
    <?php endif; ?>
</body>
<script>
    // PENGHALANG KOSMETIK SAJA — bukan security, mudah dilewati
    document.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('keydown', e => {
        if (e.key === 'F12') e.preventDefault();
        if (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(e.key.toUpperCase())) e.preventDefault();
        if (e.ctrlKey && e.key.toUpperCase() === 'U') e.preventDefault();
    });
</script>

</html>