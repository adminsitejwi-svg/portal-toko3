<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

/**
 * Daftar menu "All NOC", "Report NOC" & "Activation" (nama, ikon, keterangan) untuk halaman "Segera Hadir".
 *
 * - route : alamat halaman (sama dengan link di sidebar)
 * - judul : nama menu
 * - ikon  : ikon Tabler (ti-...)
 * - info  : penjelasan singkat di kartu
 * - soon  : true = halaman belum dibuat, tampil "Segera Hadir"
 *
 * Saat halaman yang masih "soon" selesai dibuat: ubah soon jadi false,
 * lalu arahkan route-nya ke controller halaman tersebut di Routes.php.
 */
class AllNoc extends BaseConfig
{
    public array $menu = [
        ['route' => 'DataRakDC',       'judul' => 'Data Rak DC',                 'ikon' => 'ti-server-2',        'info' => 'Data center, rak, perangkat & visual rak.', 'soon' => false],
        ['route' => 'Interkoneksi',    'judul' => 'Data Center & Interkoneksi',  'ikon' => 'ti-arrows-exchange', 'info' => 'Data center beserta interkoneksi pelanggan.', 'soon' => false],
        ['route' => 'Vlan',            'judul' => 'Data VLAN',                   'ikon' => 'ti-network',         'info' => 'VLAN per lokasi / POP dan mapping perangkat.', 'soon' => false],
        ['route' => 'NetMon',          'judul' => 'NetMon',                      'ikon' => 'ti-activity-heartbeat', 'info' => 'Kumpulan link website monitoring jaringan.', 'soon' => false],
        ['route' => 'DataRouter',      'judul' => 'Data Router',                 'ikon' => 'ti-router',          'info' => 'Inventaris router beserta lokasi & konfigurasi.', 'soon' => false],
        ['route' => 'DataSwitch',      'judul' => 'Data Switch',                 'ikon' => 'ti-switch-horizontal', 'info' => 'Inventaris switch beserta IP, versi & lokasi.', 'soon' => false],
        ['route' => 'DataOlt',         'judul' => 'Data OLT',                    'ikon' => 'ti-affiliate',       'info' => 'Inventaris OLT beserta IP, versi & lokasi.', 'soon' => false],
        ['route' => 'DataCctv', 'judul' => 'Data CCTV', 'ikon' => 'ti-device-cctv', 'info' => 'Inventaris kamera CCTV & NVR beserta IP & lokasi.', 'soon' => false],
        ['route' => 'IpPublic',        'judul' => 'Data IP Public',              'ikon' => 'ti-world',           'info' => 'Alokasi blok & alamat IP public.', 'soon' => false],
        ['route' => 'IpPrivate',       'judul' => 'Data IP Private',             'ikon' => 'ti-lock',            'info' => 'Alokasi subnet & alamat IP private.', 'soon' => true],
        ['route' => 'FtpClient',       'judul' => 'FTP Client',                  'ikon' => 'ti-folder-share',    'info' => 'Akses file server FTP NOC dari portal.', 'soon' => false],
        ['route' => 'DataOdcOdp',     'judul' => 'Data ODC & ODP',            'ikon' => 'ti-box-model-2',      'info' => 'Data ODC (Optical Distribution Cabinet) & ODP (Optical Distribution Point).', 'soon' => false],
        ['route' => 'Kmz',            'judul' => 'KMZ',                       'ikon' => 'ti-map-2',            'info' => 'File peta KMZ jalur kabel & titik jaringan.', 'soon' => false],
        ['route' => 'DevicesBackbone', 'judul' => 'Devices Backbone',            'ikon' => 'ti-router',          'info' => 'Perangkat jaringan backbone.', 'soon' => false],
        ['route' => 'Bts',             'judul' => 'Data BTS',                    'ikon' => 'ti-antenna-bars-5',  'info' => 'Data BTS & vendor BTS.', 'soon' => false],
        ['route' => 'PelangganNoc',    'judul' => 'Data Pelanggan',              'ikon' => 'ti-users',           'info' => 'Pelanggan NOC beserta perangkat & vendor.', 'soon' => false],
        ['route' => 'VendorNoc',       'judul' => 'Data Vendor',                 'ikon' => 'ti-briefcase',       'info' => 'Daftar vendor NOC.', 'soon' => false],
        ['route' => 'InventoryKantor', 'judul' => 'Asset Management',            'ikon' => 'ti-package',         'info' => 'Inventaris aset kantor.', 'soon' => false],
        ['route' => 'RekapDataMidi',   'judul' => 'Rekap Data Toko',             'ikon' => 'ti-report-analytics', 'info' => 'Rekap Data Toko All.', 'soon' => false],
        ['route' => 'DataTopologi',    'judul' => 'Data Topologi',               'ikon' => 'ti-topology-star-3', 'info' => 'Gambar topologi semua jaringan dengan draw.io.', 'soon' => false]
    ];

    // Menu Report NOC yang belum dibuat (dropdown Report NOC di sidebar), format sama dengan $menu
    public array $reportNoc = [
        ['route' => 'MonthlyReport',       'judul' => 'Monthly Report',       'ikon' => 'ti-calendar-stats', 'info' => 'Rekap laporan NOC bulanan.', 'soon' => false],
        ['route' => 'SurveyReport',        'judul' => 'Survey Report',        'ikon' => 'ti-zoom-check',     'info' => 'Laporan hasil survey lokasi.', 'soon' => false],
        ['route' => 'InstallationReport',  'judul' => 'Installation Report',  'ikon' => 'ti-plug-connected', 'info' => 'Laporan pekerjaan instalasi.', 'soon' => false],
        ['route' => 'TroubleshootReport',  'judul' => 'Troubleshoot Report',  'ikon' => 'ti-bug',            'info' => 'Laporan penanganan gangguan / troubleshoot.', 'soon' => false],
        ['route' => 'PreventiveMaintenance', 'judul' => 'Preventive Maintenance', 'ikon' => 'ti-tool',       'info' => 'Jadwal & laporan preventive maintenance perangkat jaringan.', 'soon' => false],
    ];

    // Menu Activation (bagian sidebar sebelum NOC Operation), semuanya masih "Segera Hadir"
    public array $activation = [
        ['route' => 'Spk',            'judul' => 'SPK',                     'ikon' => 'ti-file-certificate',    'info' => 'Surat Perintah Kerja untuk pekerjaan aktivasi.', 'soon' => false],
        ['route' => 'BastCorporate',  'judul' => 'BAST Corporate',          'ikon' => 'ti-building-skyscraper', 'info' => 'Berita Acara Serah Terima pelanggan corporate.', 'soon' => false],
        ['route' => 'BastAlfamidi',   'judul' => 'BAST Alfamidi',           'ikon' => 'ti-building-store',      'info' => 'Berita Acara Serah Terima toko Alfamidi.', 'soon' => false],
        ['route' => 'BastLawson',     'judul' => 'BAST Lawson',             'ikon' => 'ti-building-store',      'info' => 'Berita Acara Serah Terima toko Lawson.', 'soon' => false],
        ['route' => 'BastAlfamart',   'judul' => 'BAST Alfamart',           'ikon' => 'ti-building-store',      'info' => 'Berita Acara Serah Terima toko Alfamart.', 'soon' => false],
        ['route' => 'BastDandan',     'judul' => 'BAST Dandan',             'ikon' => 'ti-building-store',      'info' => 'Berita Acara Serah Terima toko Dandan.', 'soon' => false],
        ['route' => 'PksContract',    'judul' => 'PKS & Contract',          'ikon' => 'ti-file-text',           'info' => 'Perjanjian Kerja Sama & kontrak pelanggan.', 'soon' => false],
        ['route' => 'SuratTugas',     'judul' => 'Surat Tugas',             'ikon' => 'ti-file-text',           'info' => 'Surat tugas untuk Dinas.', 'soon' => false],
    ];

    // Menu dropdown "NMS JWI Group" di sidebar
    public array $netmon = [
        ['route' => 'DashboardNetmon', 'judul' => 'Dashboard Netmon', 'ikon' => 'ti-dashboard', 'info' => 'Ringkasan status & performa seluruh perangkat jaringan.', 'soon' => false],
        ['route' => 'DeviceMonitoring', 'judul' => 'Device Monitoring', 'ikon' => 'ti-device-desktop-analytics', 'info' => 'Monitoring perangkat jaringan lewat SNMP.', 'soon' => false],
        ['route' => 'TrafficMonitoring', 'judul' => 'Traffic Monitoring', 'ikon' => 'ti-chart-area-line', 'info' => 'Traffic RX/TX interface perangkat lewat SNMP.', 'soon' => false],
        ['route' => 'Nms', 'judul' => 'NMS Management', 'ikon' => 'ti-network', 'info' => 'Network Management System: live & history latency, CPU, RAM, traffic.', 'soon' => false],
        ['route' => 'Alert', 'judul' => 'Alert', 'ikon' => 'ti-bell-ringing', 'info' => 'Alert Center: gangguan perangkat & interface, notifikasi di navbar.', 'soon' => false],
        ['route' => 'Screen', 'judul' => 'Screen', 'ikon' => 'ti-device-tv', 'info' => 'Network Wallboard: traffic live banyak interface dalam satu layar.', 'soon' => false],
    ];

    // Menu dropdown "ACS JWI Group" di sidebar
    public array $acs = [
        ['route' => 'DashboardAcs', 'judul' => 'Dashboard ACS', 'ikon' => 'ti-dashboard', 'info' => 'Ringkasan Auto Configuration Server (ACS) JWI Group.', 'soon' => true],
        ['route' => 'AcsDevice', 'judul' => 'Devices', 'ikon' => 'ti-router', 'info' => 'ONT yang terhubung ke ACS JWI Group lewat TR-069.', 'soon' => false],
        ['route' => 'AcsParameter', 'judul' => 'Parameter Master', 'ikon' => 'ti-list-search', 'info' => 'Daftar parameter TR-069 per model ONT.', 'soon' => false],
        ['route' => 'AcsProvisioning', 'judul' => 'Provisioning', 'ikon' => 'ti-adjustments-cog', 'info' => 'Profil konfigurasi ONT yang diterapkan otomatis lewat TR-069.', 'soon' => false],
        ['route' => 'AcsSetting', 'judul' => 'Settings', 'ikon' => 'ti-settings', 'info' => 'Koneksi ONT ke ACS JWI Group lewat TR-069.', 'soon' => false],
        ['route' => 'AcsLog', 'judul' => 'Log Koneksi', 'ikon' => 'ti-history', 'info' => 'Riwayat koneksi ONT ke ACS JWI Group.', 'soon' => false],
    ];

    // Menu yang masih "Segera Hadir" (All NOC, Report NOC, Activation, NMS JWI Group & ACS JWI Group), dicari berdasarkan route
    public function cari(string $route): ?array
    {
        foreach (array_merge($this->menu, $this->reportNoc, $this->activation, $this->netmon, $this->acs) as $m) {
            if (strcasecmp($m['route'], $route) === 0) {
                return $m;
            }
        }

        return null;
    }
}
