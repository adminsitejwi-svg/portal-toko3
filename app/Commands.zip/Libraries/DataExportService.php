<?php

namespace App\Libraries;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Throwable;

/**
 * Export seluruh "halaman data" aplikasi (satu tabel = satu halaman) ke
 * CSV + Excel, masing-masing dalam folder tersendiri sesuai nama
 * halamannya — dipakai oleh Full Backup.
 *
 * Untuk 3 halaman Data Toko (Alfamidi/Lawson/Alfamart), sebagai ganti PDF
 * disertakan folder "foto" berisi foto lampiran asli tiap toko. Halaman
 * lain tidak punya PDF sama sekali (dianggap tidak perlu — cukup CSV/Excel).
 *
 * Tabel `login` dan `activity_logs` sengaja TIDAK diekspor (kredensial &
 * audit log, bukan data bisnis/halaman biasa).
 */
class DataExportService
{
    /** @var array<string, string> tabel => label halaman */
    private const PAGES = [
        'md_dc'              => 'DC',
        'md_media_koneksi'   => 'Media Koneksi',
        'md_pemilik_projek'  => 'Pemilik Projek',
        'md_vendor'          => 'Vendor Non Celullar',
        'md_vendor_cellular' => 'Vendor Celulllar',
        'md_layanan_vendor'  => 'Layanan Vendor',
        'md_merek_perangkat' => 'Merek Perangkat',
        'md_jenis_perangkat' => 'Jenis Perangkat',
        'md_type_perangkat'  => 'Type Perangkat',
        'md_pelanggan'       => 'Kategori Pelanggan',
        'md_nomer_inet'      => 'Nomor INET',
        'md_quota_simcard'   => 'Kuota Simcard',
        'md_vpn'             => 'VPN',
        'md_barang'          => 'Asset Management',
        'd_rfo'              => 'RFO',
        'md_maintenance'     => 'Maintenance',
        'd_report'           => 'Daily Report',
        'd_maintenance_report' => 'Maintenance Report',
        'd_monthly_report'     => 'Monthly Report',
        'd_survey_report'      => 'Survey Report',
        'd_installation_report' => 'Installation Report',
        'd_troubleshoot_report' => 'Troubleshoot Report',
        'd_preventive_maintenance' => 'Preventive Maintenance',
        'd_report_sat'         => 'Tiket FO Loss',
        'd_resi_pengiriman'    => 'Resi Pengiriman',
        'md_data_center'       => 'Data Center',
        'md_data_center_dc'    => 'Data Rak DC - Data Center',
        'md_data_rak'          => 'Data Rak DC - Data Rak',
        'md_data_perangkat'    => 'Data Rak DC - Data Perangkat',
        'd_vendor'             => 'Data Vendor',
        'md_netmon'            => 'NetMon',
        'md_vlan'              => 'Data VLAN',
        'md_vlan_perangkat'    => 'Data VLAN - Mapping Perangkat',
        'd_router'             => 'Data Router',
        'd_nvr'                => 'Data CCTV - NVR',
        'd_cctv'               => 'Data CCTV - Camera',
        'md_ip_public_judul'    => 'Data IP Public - Judul',
        'md_ip_public_subjudul' => 'Data IP Public - Sub Judul',
        'd_ip_public_subnet'    => 'Data IP Public - Subnet',
        'd_switch'             => 'Data Switch',
        'd_olt'                => 'Data OLT',
        'd_kmz'                => 'KMZ (daftar file)',
        'd_bast_corporate'     => 'BAST Corporate (daftar dokumen)',
        'd_bast_alfamidi'      => 'BAST Alfamidi (daftar dokumen)',
        'd_bast_lawson'        => 'BAST Lawson (daftar dokumen)',
        'd_bast_alfamart'      => 'BAST Alfamart (daftar dokumen)',
        'd_bast_dandan'        => 'BAST Dandan (daftar dokumen)',
        'd_spk'                => 'SPK (daftar dokumen)',
        'd_pks_contract'       => 'PKS & Contract (daftar dokumen)',
        'd_surat_tugas'        => 'Surat Tugas',
        'md_wilayah'           => 'Data ODC & ODP - Wilayah',
        'd_odc'                => 'Data ODC & ODP - ODC',
        'd_odp'                => 'Data ODC & ODP - ODP',
        'd_pelanggan_odp'      => 'Data ODC & ODP - Pelanggan',
        'd_interkoneksi'            => 'Data Interkoneksi',
        'd_bts'                     => 'Data BTS',
        'd_bts_vendor'              => 'Data BTS - Vendor',
        'd_devices_backbone'        => 'Devices Backbone',
        'd_pelanggan_noc'           => 'Data Pelanggan NOC',
        'd_pelanggan_noc_perangkat' => 'Data Pelanggan NOC - Perangkat',
        'd_pelanggan_noc_vendor'    => 'Data Pelanggan NOC - Vendor',
        'd_piket'                   => 'Jadwal Piket',
        'd_gangguan'                => 'Daily Report - Gangguan',
        'd_maintenance'             => 'Daily Report - Maintenance',
        'd_pengiriman'              => 'Daily Report - Pengiriman',
        'd_catatan'                 => 'Daily Report - Catatan',
        'd_follow_up'               => 'Daily Report - Follow Up',
        'd_aktivasi'                => 'Daily Report - Aktivasi',
        'd_midi'             => 'Alfamidi',
        'd_lawson'           => 'Lawson',
        'd_alfamart'         => 'Alfamart',
        'd_simcard'          => 'Data SI (Simcard)',
        'd_nomor_inet'       => 'Nomor Inet (Data Penggunaan)',
        'jadwal_noc'         => 'Jadwal NOC',
        'rekap_data_toko'      => 'Rekap Data Toko',
        'd_topologi'           => 'Data Topologi'
    ];

    /** Tabel Data Toko — dapat folder "foto" berisi lampiran asli, bukan PDF. */
    private const TOKO_TABLES = ['d_midi', 'd_lawson', 'd_alfamart', 'rekap_data_toko'];

    /**
     * Data Topologi: kolom `xml` (isi diagram draw.io) bisa sangat panjang (> batas 32.767 karakter
     * per sel Excel), jadi di CSV/Excel diganti keterangan, dan tiap diagram disimpan utuh sebagai
     * file .drawio di folder "diagram". Gambar PNG-nya disalin ke folder "gambar" (ikut $includePhotos).
     */
    private const TOPOLOGI_TABLE = 'd_topologi';

    private const HEADER_COLOR = '1F4E78';
    private const BAND_COLOR   = 'F2F6FB';
    private const BORDER_COLOR = 'DDE3EA';

    protected \Config\Backup $config;

    public function __construct()
    {
        $this->config = config('Backup');
    }

    /**
     * Export semua halaman ke dalam sub-folder $destDir/{Label Halaman}/...
     *
     * @param bool $includePhotos Sertakan folder foto/ untuk halaman Data Toko
     *                            (dipakai Full Backup). Untuk export data saja
     *                            (/backup_files), foto sengaja tidak disertakan
     *                            karena sudah ada perintah /backup_photo sendiri.
     *
     * @return array{ok: list<string>, failed: array<string, string>}
     */
    public function exportAllPages(string $destDir, bool $includePhotos = true): array
    {
        date_default_timezone_set($this->config->timezone);

        $db     = \Config\Database::connect();
        $ok     = [];
        $failed = [];

        foreach (self::PAGES as $table => $label) {
            try {
                if (! $db->tableExists($table)) {
                    $failed[$label] = "Tabel `{$table}` tidak ditemukan di database, dilewati.";
                    continue;
                }

                $rows = $db->table($table)->get()->getResultArray();
                $this->exportPage($destDir, $label, $table, $rows, $includePhotos);
                $ok[] = $label;
            } catch (Throwable $e) {
                log_message('error', "DataExportService::exportAllPages [{$table}] - " . $e->getMessage());
                $failed[$label] = 'Gagal export: ' . $e->getMessage();
            }
        }

        return ['ok' => $ok, 'failed' => $failed];
    }

    private function exportPage(string $destDir, string $label, string $table, array $rows, bool $includePhotos): void
    {
        $slug   = $this->slug($label);
        $folder = rtrim($destDir, '/\\') . DIRECTORY_SEPARATOR . $label;

        if (! is_dir($folder)) {
            mkdir($folder, 0755, true);
        }

        $headers = $rows === [] ? [] : array_keys($rows[0]);

        $isTopologi = $table === self::TOPOLOGI_TABLE;
        $rowsTabel  = $rows;
        if ($isTopologi) {
            $rowsTabel = array_map(static function (array $row): array {
                $row['xml'] = trim((string) ($row['xml'] ?? '')) === '' ? '' : 'lihat folder diagram/';

                return $row;
            }, $rows);
        }

        $this->writeCsv($folder . DIRECTORY_SEPARATOR . $slug . '.csv', $headers, $rowsTabel);
        $this->writeExcel($folder . DIRECTORY_SEPARATOR . $slug . '.xlsx', $label, $headers, $rowsTabel);

        $isToko     = in_array($table, self::TOKO_TABLES, true);
        $photoCount = 0;
        if ($includePhotos && $isToko) {
            $photoCount = $this->exportPhotos($folder, $rows);
        }

        $extraNotes = [];
        if ($isTopologi) {
            $extraNotes = $this->exportTopologi($folder, $rows, $includePhotos);
        }

        $this->writeNotes($folder . DIRECTORY_SEPARATOR . 'catatan.txt', $label, $table, $rows, $photoCount, $includePhotos && $isToko, $extraNotes);
    }

    /**
     * Data Topologi: tiap diagram -> diagram/{id}_{nama}.drawio (bisa dibuka lagi di draw.io /
     * diagrams.net), gambar PNG -> gambar/{id}_{nama}.png (PNG ini juga memuat diagramnya).
     *
     * @return list<string> baris tambahan untuk catatan.txt
     */
    private function exportTopologi(string $pageFolder, array $rows, bool $includePhotos): array
    {
        $diagramDir = $pageFolder . DIRECTORY_SEPARATOR . 'diagram';
        $gambarDir  = $pageFolder . DIRECTORY_SEPARATOR . 'gambar';
        $diagram    = 0;
        $gambar     = 0;

        foreach ($rows as $row) {
            $nama = ($row['id'] ?? '0') . '_' . ($this->slug((string) ($row['nama'] ?? '')) ?: 'topologi');

            $xml = trim((string) ($row['xml'] ?? ''));
            if ($xml !== '') {
                if (! is_dir($diagramDir)) {
                    mkdir($diagramDir, 0755, true);
                }
                file_put_contents($diagramDir . DIRECTORY_SEPARATOR . $nama . '.drawio', $xml);
                $diagram++;
            }

            // hanya file hasil simpan di public/uploads/topologi/ (proteksi path traversal)
            $relPath = trim((string) ($row['gambar'] ?? ''));
            if (! $includePhotos || $relPath === '' || ! str_starts_with($relPath, 'uploads/topologi/') || str_contains($relPath, '..')) {
                continue;
            }
            $source = FCPATH . $relPath;
            if (! is_file($source)) {
                continue;
            }
            if (! is_dir($gambarDir)) {
                mkdir($gambarDir, 0755, true);
            }
            copy($source, $gambarDir . DIRECTORY_SEPARATOR . $nama . '.png');
            $gambar++;
        }

        $lines   = [];
        $lines[] = "Diagram draw.io: {$diagram} file .drawio (lihat folder diagram/, buka di draw.io / diagrams.net)";
        $lines[] = $includePhotos
            ? "Gambar topologi: {$gambar} file PNG (lihat folder gambar/)"
            : 'Gambar topologi: tidak disertakan pada export data saja';

        return $lines;
    }

    private function writeCsv(string $path, array $headers, array $rows): void
    {
        $fh = fopen($path, 'wb');
        fwrite($fh, "\xEF\xBB\xBF"); // BOM supaya Excel baca UTF-8 dengan benar

        if ($headers !== []) {
            fputcsv($fh, $headers);
            foreach ($rows as $row) {
                fputcsv($fh, $row);
            }
        }

        fclose($fh);
    }

    private function writeExcel(string $path, string $label, array $headers, array $rows): void
    {
        $spreadsheet = new Spreadsheet();
        $sheet       = $spreadsheet->getActiveSheet();
        $sheet->setTitle(mb_substr($label, 0, 31));

        if ($headers === []) {
            $sheet->setCellValue('A1', 'Tidak ada data.');
            $sheet->getStyle('A1')->getFont()->setItalic(true)->getColor()->setRGB('888888');
            (new Xlsx($spreadsheet))->save($path);
            $spreadsheet->disconnectWorksheets();

            return;
        }

        $sheet->fromArray($headers, null, 'A1');
        $sheet->fromArray($rows, null, 'A2');

        $lastCol     = $sheet->getHighestColumn();
        $lastRow     = $sheet->getHighestRow();
        $headerRange = "A1:{$lastCol}1";
        $dataRange   = "A1:{$lastCol}{$lastRow}";

        // Header modern: fill gelap, teks putih tebal, center.
        $sheet->getStyle($headerRange)->applyFromArray([
            'font'      => ['bold' => true, 'color' => ['rgb' => 'FFFFFF'], 'size' => 11, 'name' => 'Calibri'],
            'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => self::HEADER_COLOR]],
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER, 'wrapText' => true],
            'borders'   => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => self::HEADER_COLOR]]],
        ]);
        $sheet->getRowDimension(1)->setRowHeight(24);

        // Border tipis + alignment rapi untuk seluruh data.
        $sheet->getStyle($dataRange)->applyFromArray([
            'borders'   => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => self::BORDER_COLOR]]],
            'alignment' => ['vertical' => Alignment::VERTICAL_CENTER],
            'font'      => ['name' => 'Calibri', 'size' => 10],
        ]);

        // Baris selang-seling (banded rows) supaya lebih mudah dibaca.
        for ($r = 2; $r <= $lastRow; $r++) {
            if ($r % 2 === 0) {
                $sheet->getStyle("A{$r}:{$lastCol}{$r}")->getFill()
                    ->setFillType(Fill::FILL_SOLID)
                    ->getStartColor()->setRGB(self::BAND_COLOR);
            }
        }

        $sheet->setAutoFilter($headerRange);
        $sheet->freezePane('A2');

        foreach (range('A', $lastCol) as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        (new Xlsx($spreadsheet))->save($path);
        $spreadsheet->disconnectWorksheets();
    }

    /**
     * Salin foto lampiran asli tiap toko ke folder "foto" milik halaman ini,
     * diberi awalan kode_toko supaya jelas foto itu punya toko yang mana.
     */
    private function exportPhotos(string $pageFolder, array $rows): int
    {
        $sourceDir = WRITEPATH . 'uploads' . DIRECTORY_SEPARATOR . 'lampiran';
        if (! is_dir($sourceDir)) {
            return 0;
        }

        $photoDir = $pageFolder . DIRECTORY_SEPARATOR . 'foto';
        $copied   = 0;

        foreach ($rows as $row) {
            $raw = $row['upload_lampiran'] ?? null;
            if (empty($raw)) {
                continue;
            }

            $decoded = json_decode((string) $raw, true);
            $files   = is_array($decoded) ? $decoded : [$raw];

            $storeCode = $this->slug((string) ($row['kode_toko'] ?? ('id-' . ($row['id'] ?? '0'))));

            foreach ($files as $filename) {
                $filename = basename((string) $filename); // proteksi path traversal
                $source   = $sourceDir . DIRECTORY_SEPARATOR . $filename;

                if ($filename === '' || ! is_file($source)) {
                    continue;
                }

                if (! is_dir($photoDir)) {
                    mkdir($photoDir, 0755, true);
                }

                copy($source, $photoDir . DIRECTORY_SEPARATOR . $storeCode . '_' . $filename);
                $copied++;
            }
        }

        return $copied;
    }
    private function exportRekapPhotos(string $pageFolder, array $rows): int
    {
        $photoDir   = $pageFolder . DIRECTORY_SEPARATOR . 'foto';
        $copied     = 0;
        $fileFields = ['foto_sn_fortigate', 'sn_ont_fo', 'foto_imei_modem_1'];

        foreach ($rows as $row) {
            $storeCode = $this->slug((string) ($row['kode_toko'] ?? ('id-' . ($row['id'] ?? '0'))));

            foreach ($fileFields as $field) {
                $relPath = trim((string) ($row[$field] ?? ''));
                if ($relPath === '') {
                    continue;
                }

                $filename = basename($relPath);
                $source   = FCPATH . 'uploads' . DIRECTORY_SEPARATOR . 'rekap_toko' . DIRECTORY_SEPARATOR . $filename;

                if ($filename === '' || ! is_file($source)) {
                    continue;
                }

                if (! is_dir($photoDir)) {
                    mkdir($photoDir, 0755, true);
                }

                copy($source, $photoDir . DIRECTORY_SEPARATOR . $storeCode . '_' . $filename);
                $copied++;
            }
        }

        return $copied;
    }

    private function writeNotes(string $path, string $label, string $table, array $rows, int $photoCount, bool $isToko, array $extraNotes = []): void
    {
        $count  = count($rows);
        $latest = null;
        foreach ($rows as $row) {
            if (! empty($row['created_at']) && ($latest === null || $row['created_at'] > $latest)) {
                $latest = $row['created_at'];
            }
        }

        $lines   = [];
        $lines[] = "Halaman        : {$label}";
        $lines[] = "Tabel database : {$table}";
        $lines[] = "Jumlah data    : {$count} baris";
        $lines[] = 'Data terbaru dibuat pada : ' . ($latest ?? '-');
        $lines[] = 'Backup dibuat pada       : ' . date('Y-m-d H:i:s') . ' (Asia/Jakarta)';

        if ($isToko) {
            $lines[] = "Foto lampiran  : {$photoCount} file (lihat folder foto/)";
        }

        foreach ($extraNotes as $note) {
            $lines[] = $note;
        }

        $lines[] = '';
        $lines[] = 'Catatan: sistem saat ini hanya mencatat tanggal data DIBUAT (created_at),';
        $lines[] = 'belum mencatat tanggal terakhir data DIUBAH (updated_at). Jadi tanggal di';
        $lines[] = 'atas bukan berarti seluruh data di file ini terakhir diubah pada tanggal itu.';

        file_put_contents($path, implode("\r\n", $lines));
    }

    private function slug(string $label): string
    {
        $slug = strtolower($label);
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);

        return trim((string) $slug, '-');
    }
}
